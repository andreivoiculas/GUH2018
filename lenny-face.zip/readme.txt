﻿=== Lenny Face ( ͡° ͜ʖ ͡°) Cursor Set ===

By: FedoraTippingWonderChild (http://www.rw-designer.com/user/55788) andyrocks990@gmail.com

Download: http://www.rw-designer.com/cursor-set/lenny-face

Author's description:

Le Lenny Faces ( ͡° ͜ʖ ͡°)

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.